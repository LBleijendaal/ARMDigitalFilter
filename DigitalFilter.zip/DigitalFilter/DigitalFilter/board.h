/*
 * board.h
 *
 * Created: 18/11/2019 13:59:05
 *  Author: Luuk Bleijendaal
 */ 


#ifndef BOARD_H_
#define BOARD_H_

void board_init(void);
void ioport_init(void);


#endif /* BOARD_H_ */